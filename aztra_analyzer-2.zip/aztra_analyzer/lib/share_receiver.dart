import 'package:flutter/services.dart';

/// Canciones que otras apps comparten con Aztra Analyzer ("Compartir" o
/// "Abrir con"). La parte nativa las copia a la cache y aqui se leen sus rutas.
class ShareReceiver {
  static const _channel = MethodChannel('aztra/share');

  /// Rutas de los archivos recibidos (y las borra de la lista nativa).
  static Future<List<String>> take() async {
    try {
      final r = await _channel.invokeMethod<List<dynamic>>('getSharedFiles');
      return r?.whereType<String>().toList() ?? <String>[];
    } catch (_) {
      return <String>[];
    }
  }

  /// Avisa cuando llegan archivos con la app ya abierta.
  static void listen(Future<void> Function() onShared) {
    _channel.setMethodCallHandler((call) async {
      if (call.method == 'sharedFiles') await onShared();
      return null;
    });
  }
}
