import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'app_background.dart';

/// Superficie de las tarjetas. Con Liquid Glass activo es un vidrio translucido
/// con desenfoque, brillo y borde de luz; sin el, es la tarjeta normal de siempre.
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    super.key,
    required this.child,
    this.radius = 20,
    this.blur = true,
  });

  final Widget child;
  final double radius;

  /// false = vidrio sin desenfoque (mas ligero; se usa en las listas largas).
  final bool blur;

  @override
  Widget build(BuildContext context) {
    final settings = SettingsScope.of(context);
    final cs = Theme.of(context).colorScheme;
    final r = BorderRadius.circular(radius);

    if (!settings.liquidGlass) {
      return Material(
        color: cs.surfaceContainer,
        shape: RoundedRectangleBorder(
          borderRadius: r,
          side: BorderSide(color: cs.outlineVariant.withValues(alpha: 0.5)),
        ),
        clipBehavior: Clip.antiAlias,
        child: child,
      );
    }

    // Transparencia: 0 = vidrio oscuro y opaco, 1 = muy claro y transparente.
    final t = settings.glassTransparency;
    final blackA = 0.36 * (1 - t);
    final whiteA1 = 0.04 + 0.18 * (1 - t);
    final whiteA2 = 0.01 + 0.06 * (1 - t);
    Widget glass = ColoredBox(
      color: Colors.black.withValues(alpha: blackA),
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.white.withValues(alpha: whiteA1),
              Colors.white.withValues(alpha: whiteA2),
            ],
          ),
        ),
        child: Material(type: MaterialType.transparency, child: child),
      ),
    );
    final sigma = settings.glassBlur;
    if (blur && sigma >= 0.5) {
      glass = BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: sigma, sigmaY: sigma),
        child: glass,
      );
    }
    return CustomPaint(
      foregroundPainter: _RimPainter(radius),
      child: ClipRRect(borderRadius: r, child: glass),
    );
  }
}

/// Borde de luz del vidrio: brilla arriba a la izquierda y abajo a la derecha.
class _RimPainter extends CustomPainter {
  _RimPainter(this.radius);

  final double radius;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final rrect = RRect.fromRectAndRadius(
      rect.deflate(0.6),
      Radius.circular(radius),
    );
    final rim = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..shader = ui.Gradient.linear(
        rect.topLeft,
        rect.bottomRight,
        [
          Colors.white.withValues(alpha: 0.55),
          Colors.white.withValues(alpha: 0.06),
          Colors.white.withValues(alpha: 0.28),
        ],
        [0.0, 0.5, 1.0],
      );
    canvas.drawRRect(rrect, rim);

    // Reflejo suave en la parte de arriba.
    final topH = size.height * 0.45;
    final shine = Paint()
      ..shader = ui.Gradient.linear(
        Offset(size.width / 2, 0),
        Offset(size.width / 2, topH),
        [
          Colors.white.withValues(alpha: 0.10),
          Colors.white.withValues(alpha: 0.0),
        ],
      );
    canvas.save();
    canvas.clipRRect(RRect.fromRectAndRadius(rect, Radius.circular(radius)));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, topH), shine);
    canvas.restore();
  }

  @override
  bool shouldRepaint(_RimPainter old) => old.radius != radius;
}
