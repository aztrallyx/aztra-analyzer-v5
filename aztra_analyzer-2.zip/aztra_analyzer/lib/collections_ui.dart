import 'package:flutter/material.dart';

import 'library.dart';

/// Pregunta un nombre (para crear o renombrar una coleccion).
Future<String?> askCollectionName(
  BuildContext context, {
  required String title,
  String initial = '',
}) async {
  final ctrl = TextEditingController(text: initial);
  final result = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: ctrl,
        autofocus: true,
        maxLength: 40,
        decoration: const InputDecoration(hintText: 'Ej. Compras, Mis beats'),
        onSubmitted: (v) => Navigator.of(ctx).pop(v),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(),
          child: const Text('Cancelar'),
        ),
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(ctrl.text),
          child: const Text('Aceptar'),
        ),
      ],
    ),
  );
  ctrl.dispose();
  final t = result?.trim();
  return (t == null || t.isEmpty) ? null : t;
}

/// Hoja para elegir una coleccion. Devuelve:
///  - null: se cerro sin elegir
///  - [kAllCollections]: "Todas" (solo si [includeAll])
///  - [kNoCollection]: "Sin coleccion"
///  - el nombre de la coleccion elegida o recien creada
Future<String?> pickCollection(
  BuildContext context,
  LibraryController c, {
  required String title,
  bool includeAll = false,
  bool manage = false,
}) {
  return showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSheet) {
        final names = c.collectionNames;
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(ctx).size.height * 0.75,
            ),
            child: ListView(
              shrinkWrap: true,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                if (includeAll)
                  ListTile(
                    leading: const Icon(Icons.library_music_outlined),
                    title: Text('Todas (${c.countInCollection(null)})'),
                    onTap: () => Navigator.of(ctx).pop(kAllCollections),
                  ),
                ListTile(
                  leading: const Icon(Icons.folder_off_outlined),
                  title: Text(
                    'Sin colección (${c.countInCollection(kNoCollection)})',
                  ),
                  onTap: () => Navigator.of(ctx).pop(kNoCollection),
                ),
                for (final name in names)
                  ListTile(
                    leading: const Icon(Icons.folder_outlined),
                    title: Text(name),
                    subtitle: Text('${c.countInCollection(name)} canciones'),
                    trailing: manage
                        ? PopupMenuButton<String>(
                            onSelected: (v) async {
                              if (v == 'rename') {
                                final n = await askCollectionName(
                                  ctx,
                                  title: 'Renombrar colección',
                                  initial: name,
                                );
                                if (n != null) {
                                  await c.renameCollection(name, n);
                                  setSheet(() {});
                                }
                              } else if (v == 'delete') {
                                final ok = await showDialog<bool>(
                                  context: ctx,
                                  builder: (d) => AlertDialog(
                                    title: Text('¿Borrar "$name"?'),
                                    content: const Text(
                                      'Las canciones no se borran: solo se '
                                      'quedan sin colección.',
                                    ),
                                    actions: [
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.of(d).pop(false),
                                        child: const Text('Cancelar'),
                                      ),
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.of(d).pop(true),
                                        child: const Text('Borrar'),
                                      ),
                                    ],
                                  ),
                                );
                                if (ok == true) {
                                  await c.deleteCollection(name);
                                  setSheet(() {});
                                }
                              }
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(
                                value: 'rename',
                                child: Text('Renombrar'),
                              ),
                              PopupMenuItem(
                                value: 'delete',
                                child: Text('Borrar'),
                              ),
                            ],
                          )
                        : null,
                    onTap: () => Navigator.of(ctx).pop(name),
                  ),
                ListTile(
                  leading: const Icon(Icons.add),
                  title: const Text('Nueva colección…'),
                  onTap: () async {
                    final n = await askCollectionName(
                      ctx,
                      title: 'Nueva colección',
                    );
                    if (n == null) return;
                    await c.createCollection(n);
                    if (ctx.mounted) Navigator.of(ctx).pop(n);
                  },
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}
