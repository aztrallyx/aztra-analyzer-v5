import 'package:flutter/material.dart';

/// Color base de Mornye (se usa si el telefono no da colores dinamicos).
const kSeedColor = Color(0xFF1DB954);

ThemeData buildTheme(
  ColorScheme? dynamicDark,
  String? fontFamily, {
  bool hasBackground = false,
  Color? accent,
}) {
  final base = accent != null
      ? ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark)
      : (dynamicDark ??
            ColorScheme.fromSeed(
              seedColor: kSeedColor,
              brightness: Brightness.dark,
            ));
  final opaqueContainer = base.surfaceContainer;
  // Con imagen de fondo, las tarjetas se vuelven semitransparentes.
  final scheme = base.copyWith(
    surface: Colors.black,
    surfaceContainer: hasBackground
        ? opaqueContainer.withValues(alpha: 0.78)
        : opaqueContainer,
  );
  final bg = hasBackground ? Colors.transparent : Colors.black;
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: bg,
    fontFamily: fontFamily,
    appBarTheme: AppBarTheme(
      backgroundColor: bg,
      surfaceTintColor: Colors.transparent,
      scrolledUnderElevation: 0,
      centerTitle: true,
    ),
    // Los menus siempre opacos, aunque haya fondo.
    popupMenuTheme: PopupMenuThemeData(color: opaqueContainer),
    dividerTheme: DividerThemeData(color: scheme.outlineVariant),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}
