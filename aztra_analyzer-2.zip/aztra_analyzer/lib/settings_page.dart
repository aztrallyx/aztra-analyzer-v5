import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';

import 'app_background.dart';
import 'format.dart';
import 'library.dart';
import 'settings.dart';
import 'store.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({
    super.key,
    required this.controller,
    required this.settings,
  });

  final LibraryController controller;
  final AppSettings settings;

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  int _refresh = 0;

  AppSettings get _s => widget.settings;

  Widget _section(String text) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 20, 20, 6),
    child: Text(
      text,
      style: TextStyle(
        color: Theme.of(context).colorScheme.primary,
        fontSize: 13,
        fontWeight: FontWeight.w600,
      ),
    ),
  );

  Widget _choice({
    required String title,
    String? subtitle,
    required bool selected,
    required VoidCallback onTap,
  }) => ListTile(
    title: Text(title),
    subtitle: subtitle == null ? null : Text(subtitle),
    trailing: selected ? const Icon(Icons.check) : null,
    onTap: onTap,
  );

  Future<void> _pickCustomFont() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.any);
    final file = res?.files.single;
    final path = file?.path;
    if (file == null || path == null) return;
    final ok = await _s.importCustomFont(path, file.name);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          ok
              ? 'Fuente aplicada: ${file.name}'
              : 'No pude usar ese archivo. Elige una fuente .ttf u .otf.',
        ),
      ),
    );
  }

  static String _hex(Color c) =>
      '#${(c.toARGB32() & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase()}';

  Future<void> _pickAccent() async {
    const swatches = <Color>[
      Color(0xFF1DB954),
      Color(0xFF00B8D4),
      Color(0xFF2979FF),
      Color(0xFF7C4DFF),
      Color(0xFFE040FB),
      Color(0xFFFF4081),
      Color(0xFFFF5252),
      Color(0xFFFF9100),
      Color(0xFFFFD600),
      Color(0xFFFFFFFF),
    ];
    final hexCtrl = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Color de acento'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  for (final c in swatches)
                    InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () {
                        _s.setAccentColor(c);
                        Navigator.of(ctx).pop();
                      },
                      child: CircleAvatar(radius: 18, backgroundColor: c),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              TextField(
                controller: hexCtrl,
                maxLength: 7,
                decoration: const InputDecoration(
                  labelText: 'O escribe un color (ej. #FF6A00)',
                  counterText: '',
                ),
                onSubmitted: (v) {
                  final c = _parseHex(v);
                  if (c != null) {
                    _s.setAccentColor(c);
                    Navigator.of(ctx).pop();
                  }
                },
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              _s.setAccentColor(null);
              Navigator.of(ctx).pop();
            },
            child: const Text('Automático'),
          ),
          TextButton(
            onPressed: () {
              final c = _parseHex(hexCtrl.text);
              if (c != null) {
                _s.setAccentColor(c);
                Navigator.of(ctx).pop();
              }
            },
            child: const Text('Aplicar'),
          ),
        ],
      ),
    );
    hexCtrl.dispose();
  }

  static Color? _parseHex(String text) {
    final t = text.trim().replaceFirst('#', '');
    if (t.length != 6) return null;
    final v = int.tryParse(t, radix: 16);
    return v == null ? null : Color(0xFF000000 | v);
  }

  Future<void> _pickBackground() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.image);
    final file = res?.files.single;
    final path = file?.path;
    if (file == null || path == null) return;
    final ok = await _s.setBackground(path, file.name);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          ok
              ? 'Fondo aplicado'
              : 'No pude usar ese archivo. Elige una imagen JPG, PNG o WebP.',
        ),
      ),
    );
  }

  Future<void> _exportBackup() async {
    final path = await widget.controller.exportBackup();
    if (!mounted) return;
    if (path == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Todavía no hay resultados para respaldar.')),
      );
      return;
    }
    await Share.shareXFiles([XFile(path)]);
  }

  Future<void> _importBackup() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.any);
    final path = res?.files.single.path;
    if (path == null) return;
    final n = await widget.controller.importBackup(path);
    if (!mounted) return;
    setState(() => _refresh++);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          n < 0
              ? 'Ese archivo no es un respaldo de Aztra Analyzer.'
              : 'Respaldo importado: $n canciones.',
        ),
      ),
    );
  }

  Future<void> _confirmClear() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('¿Borrar resultados guardados?'),
        content: const Text(
          'Se borran los números de todas las canciones analizadas. '
          'Tendrás que volver a analizar tus carpetas.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancelar'),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Borrar'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await widget.controller.clearAll();
    if (mounted) setState(() => _refresh++);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _s,
      builder: (context, _) {
        return AppScaffold(
          appBar: AppBar(title: const Text('Ajustes')),
          body: ListView(
            padding: const EdgeInsets.only(bottom: 32),
            children: [
              _section('Apariencia'),
              SwitchListTile(
                title: const Text('Liquid Glass'),
                subtitle: const Text(
                  'Tarjetas de vidrio translúcido con desenfoque. Se ve mejor '
                  'con una imagen de fondo y gasta un poco más de batería.',
                ),
                value: _s.liquidGlass,
                onChanged: _s.setLiquidGlass,
              ),
              if (_s.liquidGlass) ...[
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
                  child: Text(
                    'Desenfoque: ${_s.glassBlur.round()}',
                    style: const TextStyle(fontSize: 14),
                  ),
                ),
                Slider(
                  value: _s.glassBlur,
                  min: 0,
                  max: 40,
                  onChanged: (v) => _s.setGlassBlur(v, save: false),
                  onChangeEnd: (v) => _s.setGlassBlur(v),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                  child: Text(
                    'Transparencia: ${(_s.glassTransparency * 100).round()}%',
                    style: const TextStyle(fontSize: 14),
                  ),
                ),
                Slider(
                  value: _s.glassTransparency,
                  min: 0,
                  max: 1,
                  onChanged: (v) => _s.setGlassTransparency(v, save: false),
                  onChangeEnd: (v) => _s.setGlassTransparency(v),
                ),
              ],
              ListTile(
                title: const Text('Color de acento'),
                subtitle: Text(
                  _s.accentColor == null
                      ? 'Automático (colores de tu teléfono)'
                      : _hex(_s.accentColor!),
                ),
                trailing: CircleAvatar(
                  radius: 12,
                  backgroundColor:
                      _s.accentColor ?? Theme.of(context).colorScheme.primary,
                ),
                onTap: _pickAccent,
              ),
              _section('Fondo'),
              ListTile(
                title: Text(
                  _s.hasBackground ? 'Cambiar imagen de fondo' : 'Poner imagen de fondo',
                ),
                subtitle: Text(
                  _s.hasBackground
                      ? (_s.backgroundLabel ?? 'Imagen elegida')
                      : 'Ahora usa los colores por defecto',
                ),
                trailing: const Icon(Icons.image_outlined),
                onTap: _pickBackground,
              ),
              if (_s.hasBackground) ...[
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
                  child: Text(
                    'Oscurecer fondo: ${(_s.backgroundDim * 100).round()}%',
                    style: const TextStyle(fontSize: 14),
                  ),
                ),
                Slider(
                  value: _s.backgroundDim,
                  min: 0,
                  max: 0.85,
                  onChanged: (v) => _s.setBackgroundDim(v, save: false),
                  onChangeEnd: (v) => _s.setBackgroundDim(v),
                ),
                ListTile(
                  title: const Text('Quitar fondo'),
                  trailing: const Icon(Icons.hide_image_outlined),
                  onTap: _s.clearBackground,
                ),
              ],
              _section('Fuente'),
              _choice(
                title: 'Google Sans Flex',
                subtitle: 'La misma que usa Mornye',
                selected: _s.font == 'google_sans_flex',
                onTap: () => _s.setFont('google_sans_flex'),
              ),
              _choice(
                title: 'Inter',
                selected: _s.font == 'inter',
                onTap: () => _s.setFont('inter'),
              ),
              _choice(
                title: 'Del sistema',
                subtitle: 'La fuente de tu teléfono',
                selected: _s.font == 'system',
                onTap: () => _s.setFont('system'),
              ),
              _choice(
                title: 'Mi fuente',
                subtitle: _s.customLoaded
                    ? _s.customFontLabel
                    : 'Toca para elegir un archivo .ttf u .otf',
                selected: _s.font == 'custom',
                onTap: () =>
                    _s.customLoaded ? _s.setFont('custom') : _pickCustomFont(),
              ),
              if (_s.customLoaded)
                ListTile(
                  title: const Text('Cambiar mi fuente…'),
                  subtitle: const Text('Elige otro archivo .ttf u .otf'),
                  trailing: const Icon(Icons.upload_file_outlined),
                  onTap: _pickCustomFont,
                ),
              _section('Velocidad de análisis'),
              _choice(
                title: 'Normal',
                subtitle: 'Una canción a la vez. Menos calor y batería',
                selected: _s.analysisThreads == 1,
                onTap: () => _s.setAnalysisThreads(1),
              ),
              _choice(
                title: 'Rápido',
                subtitle: 'Dos canciones a la vez',
                selected: _s.analysisThreads == 2,
                onTap: () => _s.setAnalysisThreads(2),
              ),
              _choice(
                title: 'Máximo',
                subtitle: 'Tres a la vez. Más rápido, pero calienta más y gasta más batería',
                selected: _s.analysisThreads == 3,
                onTap: () => _s.setAnalysisThreads(3),
              ),
              _section('Espectrogramas guardados'),
              for (final mb in const [0, 32, 64, 128])
                _choice(
                  title: mb == 0 ? 'No guardar' : 'Hasta $mb MB',
                  subtitle: mb == 0
                      ? 'Se generan cada vez que abres una canción'
                      : mb == 64
                      ? 'Recomendado. Borra los más viejos al pasarse'
                      : null,
                  selected: _s.spectrogramBudgetMb == mb,
                  onTap: () => _s.setSpectrogramBudgetMb(mb),
                ),
              FutureBuilder<int>(
                key: ValueKey('spec$_refresh'),
                future: SpectrogramCache.sizeBytes(),
                builder: (context, snap) => ListTile(
                  title: const Text('Borrar espectrogramas guardados'),
                  subtitle: Text(
                    'Ocupan ${formatBytes(snap.data ?? 0)} ahora mismo',
                  ),
                  trailing: const Icon(Icons.delete_outline),
                  onTap: () async {
                    await SpectrogramCache.clear();
                    if (mounted) setState(() => _refresh++);
                  },
                ),
              ),
              _section('Respaldo'),
              ListTile(
                title: const Text('Exportar respaldo'),
                subtitle: const Text(
                  'Guarda tus resultados y colecciones en un archivo para '
                  'no perderlos si reinstalas o cambias de teléfono',
                ),
                trailing: const Icon(Icons.upload_file_outlined),
                onTap: _exportBackup,
              ),
              ListTile(
                title: const Text('Importar respaldo'),
                subtitle: const Text(
                  'Las rutas son las del teléfono donde se hizo; si la '
                  'música está en otra carpeta, los datos se ven pero no se '
                  'puede abrir el espectrograma',
                ),
                trailing: const Icon(Icons.download_outlined),
                onTap: _importBackup,
              ),
              _section('Resultados guardados'),
              FutureBuilder<int>(
                key: ValueKey('store$_refresh'),
                future: ResultsStore.sizeBytes(),
                builder: (context, snap) => ListTile(
                  title: const Text('Borrar todos los resultados'),
                  subtitle: Text(
                    '${widget.controller.totalItems} canciones · '
                    '${formatBytes(snap.data ?? 0)}',
                  ),
                  trailing: const Icon(Icons.delete_outline),
                  onTap: _confirmClear,
                ),
              ),
              _section('Permisos'),
              ListTile(
                title: const Text('Acceso a todos los archivos'),
                subtitle: const Text(
                  'Solo si la app no encuentra canciones en una carpeta',
                ),
                onTap: () => Permission.manageExternalStorage.request(),
              ),
              _section('Acerca de'),
              ListTile(
                title: const Text('Aztra Analyzer 2.5'),
                subtitle: const Text(
                  'Analizador basado en el de Mornye (LGPL-3.0). '
                  'Fuentes Google Sans Flex e Inter (SIL OFL).',
                ),
                onTap: () {
                  // La pagina de licencias de Flutter usa el fondo del tema:
                  // se le pone fondo negro para que no quede transparente.
                  final theme = Theme.of(context);
                  Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => Theme(
                        data: theme.copyWith(
                          scaffoldBackgroundColor: Colors.black,
                          appBarTheme: theme.appBarTheme.copyWith(
                            backgroundColor: Colors.black,
                          ),
                        ),
                        child: const LicensePage(
                          applicationName: 'Aztra Analyzer',
                          applicationVersion: '2.5.0',
                        ),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }
}
