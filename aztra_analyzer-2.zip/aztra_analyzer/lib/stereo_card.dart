import 'package:flutter/material.dart';

import 'glass.dart';
import 'library.dart';

/// Tarjeta de la pantalla de detalle: ancho estereo, fase y compatibilidad con mono.
class StereoCard extends StatefulWidget {
  const StereoCard({super.key, required this.item, required this.controller});

  final Item item;
  final LibraryController controller;

  @override
  State<StereoCard> createState() => _StereoCardState();
}

class _StereoCardState extends State<StereoCard> {
  bool _busy = false;
  String? _error;
  bool _isMono = false;

  Future<void> _run({bool force = false}) async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final r = await widget.controller.computeStereo(
        widget.item,
        force: force,
      );
      if (r == null) _isMono = true;
    } catch (e) {
      _error = e.toString().replaceFirst('Exception: ', '');
    }
    if (!mounted) return;
    setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final data = widget.item.data!;
    final st = widget.controller.stereoFor(widget.item);

    Widget line(String label, String value, String verdict, {bool bad = false}) =>
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Text.rich(
            TextSpan(
              children: [
                TextSpan(
                  text: '$label: ',
                  style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
                ),
                TextSpan(
                  text: value,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                TextSpan(
                  text: '  $verdict',
                  style: TextStyle(
                    color: bad ? cs.error : cs.onSurfaceVariant,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        );

    return GlassPanel(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Estéreo y compatibilidad con mono',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                  ),
                ),
                if (st != null && !_busy)
                  IconButton(
                    icon: const Icon(Icons.refresh, size: 20),
                    tooltip: 'Volver a calcular',
                    visualDensity: VisualDensity.compact,
                    color: cs.onSurfaceVariant,
                    onPressed: () => _run(force: true),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            if (data.channels == 1 || _isMono)
              Text(
                'Esta canción es mono.',
                style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
              )
            else if (_busy) ...[
              const LinearProgressIndicator(minHeight: 2),
              const SizedBox(height: 8),
              Text(
                'Analizando… tarda unos segundos.',
                style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
              ),
            ] else if (st == null) ...[
              FilledButton.tonal(
                onPressed: _run,
                child: const Text('Analizar estéreo'),
              ),
              if (_error != null) ...[
                const SizedBox(height: 8),
                Text(_error!, style: TextStyle(color: cs.error, fontSize: 12)),
              ],
            ] else ...[
              line(
                'Ancho',
                '${st.widthPct.round()}%',
                st.widthLabel,
              ),
              line(
                'Fase (L/R)',
                st.corr.toStringAsFixed(2),
                st.corrLabel,
                bad: st.corr < 0,
              ),
              line(
                'Al sumar a mono',
                '${st.monoLossDb.toStringAsFixed(1)} dB',
                st.monoLabel,
                bad: st.monoLossDb < -6,
              ),
              line(
                'Graves (< 120 Hz)',
                st.bassCorr.toStringAsFixed(2),
                st.bassLabel,
                bad: st.bassCorr < 0.5,
              ),
              if (st.negativePct >= 5)
                line(
                  'Tiempo con fase negativa',
                  '${st.negativePct.round()}%',
                  'revisa la mezcla en mono',
                  bad: true,
                ),
              Text(
                'Medido sobre hasta 150 s de la canción. Mono perfecto = fase 1.00 '
                'y 0 dB; canales independientes = fase 0.00 y −3 dB.',
                style: TextStyle(color: cs.onSurfaceVariant, fontSize: 11),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
