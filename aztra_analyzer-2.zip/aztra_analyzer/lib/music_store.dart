import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'dsp.dart';

/// Guarda el analisis musical (BPM, tonalidad, balance) de cada cancion.
/// Son unos 200 bytes por cancion.
class MusicStore {
  static Future<File> _file() async {
    final dir = await getApplicationSupportDirectory();
    return File('${dir.path}/music_v1.json');
  }

  static Future<Map<String, MusicAnalysis>> load() async {
    final out = <String, MusicAnalysis>{};
    try {
      final f = await _file();
      if (!await f.exists()) return out;
      final json = jsonDecode(await f.readAsString()) as Map<String, dynamic>;
      for (final e in json.entries) {
        try {
          out[e.key] = MusicAnalysis.fromJson(
            Map<String, dynamic>.from(e.value as Map),
          );
        } catch (_) {}
      }
    } catch (_) {}
    return out;
  }

  static Future<void> save(Map<String, MusicAnalysis> items) async {
    try {
      final f = await _file();
      final tmp = File('${f.path}.tmp');
      await tmp.writeAsString(
        jsonEncode({for (final e in items.entries) e.key: e.value.toJson()}),
      );
      await tmp.rename(f.path);
    } catch (_) {}
  }

  static Future<void> clear() async {
    try {
      final f = await _file();
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }
}
