// Tarjeta del espectrograma. Misma estructura, tamanos, ejes y paleta que la
// de Mornye (el pintor y la paleta se copiaron tal cual).
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'format.dart';

class SpectrogramCard extends StatelessWidget {
  const SpectrogramCard({
    super.key,
    required this.image,
    required this.loading,
    required this.errorText,
    required this.sampleRate,
    required this.duration,
    required this.channels,
    required this.selectedChannel,
    required this.onChannelChanged,
    required this.onSave,
  });

  final ui.Image? image;
  final bool loading;
  final String? errorText;
  final int sampleRate;
  final double duration;
  final int channels;
  final int selectedChannel;
  final ValueChanged<int> onChannelChanged;
  final VoidCallback? onSave;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    const labelColor = Color(0xFFB5B5B5);
    final maxFreq = sampleRate / 2;

    return Card(
      elevation: 0,
      margin: EdgeInsets.zero,
      color: Colors.black,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: cs.outlineVariant.withValues(alpha: 0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(12, 4, 4, 0),
            child: Row(
              children: [
                Expanded(
                  child: channels > 1
                      ? SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: [
                              ChoiceChip(
                                showCheckmark: true,
                                label: const Text('Canales'),
                                selected: selectedChannel < 0,
                                onSelected: loading
                                    ? null
                                    : (_) => onChannelChanged(-1),
                              ),
                              for (
                                var channel = 0;
                                channel < channels;
                                channel++
                              ) ...[
                                const SizedBox(width: 6),
                                ChoiceChip(
                                  showCheckmark: true,
                                  label: Text('Ch ${channel + 1}'),
                                  selected: selectedChannel == channel,
                                  onSelected: loading
                                      ? null
                                      : (_) => onChannelChanged(channel),
                                ),
                              ],
                            ],
                          ),
                        )
                      : const SizedBox.shrink(),
                ),
                if (onSave != null)
                  IconButton(
                    icon: const Icon(Icons.download_outlined, size: 20),
                    tooltip: 'Guardar espectrograma',
                    color: labelColor,
                    onPressed: loading ? null : onSave,
                  ),
              ],
            ),
          ),
          if (loading)
            const Padding(
              padding: EdgeInsets.fromLTRB(12, 0, 12, 0),
              child: LinearProgressIndicator(minHeight: 2),
            ),
          _ZoomPlot(
            image: image,
            errorText: errorText,
            maxFreq: maxFreq,
            duration: duration,
            labelColor: labelColor,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(40, 0, 10, 8),
            child: Row(
              children: [
                const Text(
                  '-120 dBFS',
                  style: TextStyle(color: labelColor, fontSize: 10),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Container(
                    height: 8,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      gradient: LinearGradient(colors: _legendColors()),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                const Text(
                  '0 dBFS',
                  style: TextStyle(color: labelColor, fontSize: 10),
                ),
              ],
            ),
          ),
          Divider(height: 1, color: cs.outlineVariant.withValues(alpha: 0.25)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: [
                Text(
                  'Frecuencia de muestreo: $sampleRate Hz',
                  style: const TextStyle(color: labelColor, fontSize: 11),
                ),
                const Spacer(),
                Text(
                  'Nyquist: ${(maxFreq / 1000).toStringAsFixed(1)} kHz',
                  style: const TextStyle(color: labelColor, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static List<Color> _legendColors() {
    return List.generate(20, (i) {
      final c = _spekColorRGB(i / 19.0);
      return Color.fromARGB(255, c[0], c[1], c[2]);
    });
  }
}

class _SpectrogramPainter extends CustomPainter {
  final ui.Image image;
  final double maxFreqHz;
  final double durationSec;
  final Color labelColor;
  final Color gridColor;

  /// Ventana visible (fracciones 0..1). Frecuencia: 0 = 0 Hz, 1 = Nyquist.
  final double viewX0;
  final double viewX1;
  final double viewY0;
  final double viewY1;

  static const double leftGutter = 34;
  static const double bottomGutter = 18;

  _SpectrogramPainter({
    required this.image,
    required this.maxFreqHz,
    required this.durationSec,
    required this.labelColor,
    required this.gridColor,
    this.viewX0 = 0.0,
    this.viewX1 = 1.0,
    this.viewY0 = 0.0,
    this.viewY1 = 1.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final plot = Rect.fromLTWH(
      leftGutter,
      0,
      size.width - leftGutter,
      size.height - bottomGutter,
    );
    if (plot.width <= 0 || plot.height <= 0) return;

    // La imagen tiene la frecuencia mas alta arriba: y = (1 - fraccion) * alto.
    final src = Rect.fromLTRB(
      viewX0 * image.width,
      (1 - viewY1) * image.height,
      viewX1 * image.width,
      (1 - viewY0) * image.height,
    );
    canvas.drawImageRect(
      image,
      src,
      plot,
      Paint()..filterQuality = FilterQuality.medium,
    );

    final gridPaint = Paint()
      ..color = gridColor
      ..strokeWidth = 1;

    // Eje de frecuencia (Y).
    final fMinK = viewY0 * maxFreqHz / 1000.0;
    final fMaxK = viewY1 * maxFreqHz / 1000.0;
    final rangeK = fMaxK - fMinK;
    if (rangeK > 0) {
      final step = _niceStepKHz(rangeK);
      var fk = (fMinK / step).ceil() * step;
      while (fk <= fMaxK + 0.0001) {
        final ratio = (fk - fMinK) / rangeK;
        final y = plot.bottom - ratio * plot.height;
        canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), gridPaint);
        _drawText(
          canvas,
          fk < 0.0001
              ? '0'
              : (step >= 1 ? '${fk.toStringAsFixed(0)}k' : '${fk.toStringAsFixed(1)}k'),
          Offset(plot.left - 5, y),
          align: _TextAlignV.rightCenter,
        );
        fk += step;
      }
    }

    // Eje de tiempo (X).
    final tMin = viewX0 * durationSec;
    final tMax = viewX1 * durationSec;
    final rangeT = tMax - tMin;
    if (durationSec > 0 && rangeT > 0) {
      final step = _niceStepSec(rangeT);
      var ts = (tMin / step).ceil() * step;
      while (ts <= tMax + 0.001) {
        final ratio = (ts - tMin) / rangeT;
        final x = plot.left + ratio * plot.width;
        canvas.drawLine(Offset(x, plot.top), Offset(x, plot.bottom), gridPaint);
        _drawText(
          canvas,
          step >= 1 ? formatClock(ts) : '${ts.toStringAsFixed(1)}s',
          Offset(x, plot.bottom + 3),
          align: _TextAlignV.topCenter,
        );
        ts += step;
      }
    }
  }

  void _drawText(
    Canvas canvas,
    String text,
    Offset anchor, {
    required _TextAlignV align,
  }) {
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(color: labelColor, fontSize: 10),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    double dx = anchor.dx;
    double dy = anchor.dy;
    switch (align) {
      case _TextAlignV.rightCenter:
        dx = anchor.dx - tp.width;
        dy = anchor.dy - tp.height / 2;
        break;
      case _TextAlignV.topCenter:
        dx = anchor.dx - tp.width / 2;
        dy = anchor.dy;
        break;
    }
    tp.paint(canvas, Offset(dx, dy));
  }

  static double _niceStepKHz(double maxKHz) {
    const candidates = [0.1, 0.2, 0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0];
    for (final c in candidates) {
      if (maxKHz / c <= 6) return c;
    }
    return 100.0;
  }

  static double _niceStepSec(double dur) {
    const candidates = [
      0.5, 1.0, 2.0, 5.0, 10.0, 15.0, 30.0, 60.0, 120.0, 300.0, 600.0,
    ];
    for (final c in candidates) {
      if (dur / c <= 6) return c;
    }
    return 1200.0;
  }

  @override
  bool shouldRepaint(covariant _SpectrogramPainter old) =>
      old.image != image ||
      old.maxFreqHz != maxFreqHz ||
      old.durationSec != durationSec ||
      old.viewX0 != viewX0 ||
      old.viewX1 != viewX1 ||
      old.viewY0 != viewY0 ||
      old.viewY1 != viewY1;
}

enum _TextAlignV { rightCenter, topCenter }

List<int> _spekColorRGB(double intensity) {
  int r, g, b;
  if (intensity < 0.08) {
    final t = intensity / 0.08;
    r = 0;
    g = 0;
    b = (t * 80).floor();
  } else if (intensity < 0.18) {
    final t = (intensity - 0.08) / 0.10;
    r = (t * 50).floor();
    g = (t * 30).floor();
    b = (80 + t * 175).floor();
  } else if (intensity < 0.28) {
    final t = (intensity - 0.18) / 0.10;
    r = (50 + t * 150).floor();
    g = (30 - t * 30).floor();
    b = (255 - t * 55).floor();
  } else if (intensity < 0.40) {
    final t = (intensity - 0.28) / 0.12;
    r = (200 + t * 55).floor();
    g = 0;
    b = (200 - t * 200).floor();
  } else if (intensity < 0.52) {
    final t = (intensity - 0.40) / 0.12;
    r = 255;
    g = (t * 100).floor();
    b = 0;
  } else if (intensity < 0.65) {
    final t = (intensity - 0.52) / 0.13;
    r = 255;
    g = (100 + t * 80).floor();
    b = 0;
  } else if (intensity < 0.78) {
    final t = (intensity - 0.65) / 0.13;
    r = 255;
    g = (180 + t * 55).floor();
    b = (t * 30).floor();
  } else if (intensity < 0.90) {
    final t = (intensity - 0.78) / 0.12;
    r = 255;
    g = (235 + t * 20).floor();
    b = (30 + t * 100).floor();
  } else {
    final t = (intensity - 0.90) / 0.10;
    r = 255;
    g = 255;
    b = (130 + t * 125).floor();
  }
  return [r.clamp(0, 255), g.clamp(0, 255), b.clamp(0, 255)];
}


/// El grafico con botones de zoom y deslizadores para moverse por la imagen.
class _ZoomPlot extends StatefulWidget {
  const _ZoomPlot({
    required this.image,
    required this.errorText,
    required this.maxFreq,
    required this.duration,
    required this.labelColor,
  });

  final ui.Image? image;
  final String? errorText;
  final double maxFreq;
  final double duration;
  final Color labelColor;

  @override
  State<_ZoomPlot> createState() => _ZoomPlotState();
}

class _ZoomPlotState extends State<_ZoomPlot> {
  double _zt = 1; // zoom en el tiempo
  double _zf = 1; // zoom en la frecuencia
  double _t0 = 0; // inicio de la ventana (fraccion 0..1)
  double _f0 = 0;

  double get _lenT => 1 / _zt;
  double get _lenF => 1 / _zf;

  void _zoomTime(double factor) {
    final center = _t0 + _lenT / 2;
    _zt = (_zt * factor).clamp(1.0, 32.0).toDouble();
    _t0 = (center - _lenT / 2).clamp(0.0, 1 - _lenT).toDouble();
  }

  void _zoomFreq(double factor) {
    final center = _f0 + _lenF / 2;
    _zf = (_zf * factor).clamp(1.0, 16.0).toDouble();
    _f0 = (center - _lenF / 2).clamp(0.0, 1 - _lenF).toDouble();
  }

  void _reset() {
    _zt = 1;
    _zf = 1;
    _t0 = 0;
    _f0 = 0;
  }

  /// Enfoca la zona alta del espectro (de 15 kHz a Nyquist), donde se ve el corte.
  void _focusCutoff() {
    final maxF = widget.maxFreq;
    if (maxF <= 16000) return;
    _zf = maxF / (maxF - 15000);
    _f0 = 15000 / maxF;
    _f0 = _f0.clamp(0.0, 1 - _lenF).toDouble();
  }

  @override
  Widget build(BuildContext context) {
    final img = widget.image;
    final zoomed = _zt > 1 || _zf > 1;
    final cs = Theme.of(context).colorScheme;

    Widget zoomGroup(
      String label,
      double zoom,
      VoidCallback onMinus,
      VoidCallback onPlus,
    ) {
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: TextStyle(color: widget.labelColor, fontSize: 11)),
          IconButton(
            icon: const Icon(Icons.remove_circle_outline, size: 20),
            visualDensity: VisualDensity.compact,
            color: widget.labelColor,
            tooltip: 'Alejar $label',
            onPressed: zoom > 1 ? onMinus : null,
          ),
          Text(
            '×${zoom < 10 ? zoom.toStringAsFixed(zoom == zoom.roundToDouble() ? 0 : 1) : zoom.toStringAsFixed(0)}',
            style: TextStyle(color: widget.labelColor, fontSize: 11),
          ),
          IconButton(
            icon: const Icon(Icons.add_circle_outline, size: 20),
            visualDensity: VisualDensity.compact,
            color: widget.labelColor,
            tooltip: 'Acercar $label',
            onPressed: onPlus,
          ),
        ],
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(6, 4, 10, 4),
          child: LayoutBuilder(
            builder: (context, constraints) {
              const leftGutter = 34.0;
              const bottomGutter = 18.0;
              final plotWidth = constraints.maxWidth - leftGutter;
              final plotHeight = plotWidth / 2.0;
              final totalHeight = plotHeight + bottomGutter;
              return SizedBox(
                width: constraints.maxWidth,
                height: totalHeight,
                child: img == null
                    ? Padding(
                        padding: const EdgeInsets.only(
                          left: leftGutter,
                          bottom: bottomGutter,
                        ),
                        child: Center(
                          child: widget.errorText != null
                              ? Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Text(
                                    widget.errorText!,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: widget.labelColor,
                                      fontSize: 12,
                                    ),
                                  ),
                                )
                              : Text(
                                  'Generando espectrograma…',
                                  style: TextStyle(
                                    color: widget.labelColor,
                                    fontSize: 12,
                                  ),
                                ),
                        ),
                      )
                    : CustomPaint(
                        painter: _SpectrogramPainter(
                          image: img,
                          maxFreqHz: widget.maxFreq,
                          durationSec: widget.duration,
                          labelColor: widget.labelColor,
                          gridColor: Colors.white.withValues(alpha: 0.10),
                          viewX0: _t0,
                          viewX1: _t0 + _lenT,
                          viewY0: _f0,
                          viewY1: _f0 + _lenF,
                        ),
                        size: Size(constraints.maxWidth, totalHeight),
                      ),
              );
            },
          ),
        ),
        if (img != null) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 0, 6, 0),
            child: Wrap(
              spacing: 4,
              runSpacing: 0,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                zoomGroup(
                  'Tiempo',
                  _zt,
                  () => setState(() => _zoomTime(0.5)),
                  () => setState(() => _zoomTime(2)),
                ),
                zoomGroup(
                  'Frec.',
                  _zf,
                  () => setState(() => _zoomFreq(0.5)),
                  () => setState(() => _zoomFreq(2)),
                ),
                if (widget.maxFreq > 16000)
                  TextButton(
                    onPressed: () => setState(_focusCutoff),
                    child: const Text(
                      'Ver 15 kHz+',
                      style: TextStyle(fontSize: 11),
                    ),
                  ),
                if (zoomed)
                  TextButton(
                    onPressed: () => setState(_reset),
                    child: const Text(
                      'Restablecer',
                      style: TextStyle(fontSize: 11),
                    ),
                  ),
              ],
            ),
          ),
          if (_zt > 1)
            Padding(
              padding: const EdgeInsets.fromLTRB(40, 0, 10, 0),
              child: Row(
                children: [
                  Text(
                    'Mover en el tiempo',
                    style: TextStyle(color: widget.labelColor, fontSize: 10),
                  ),
                  Expanded(
                    child: Slider(
                      value: _t0.clamp(0.0, 1 - _lenT).toDouble(),
                      min: 0,
                      max: 1 - _lenT,
                      activeColor: cs.primary,
                      onChanged: (v) => setState(() => _t0 = v),
                    ),
                  ),
                ],
              ),
            ),
          if (_zf > 1)
            Padding(
              padding: const EdgeInsets.fromLTRB(40, 0, 10, 0),
              child: Row(
                children: [
                  Text(
                    'Mover en frecuencia',
                    style: TextStyle(color: widget.labelColor, fontSize: 10),
                  ),
                  Expanded(
                    child: Slider(
                      value: _f0.clamp(0.0, 1 - _lenF).toDouble(),
                      min: 0,
                      max: 1 - _lenF,
                      activeColor: cs.primary,
                      onChanged: (v) => setState(() => _f0 = v),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ],
    );
  }
}
