import 'package:flutter/material.dart';

import 'settings.dart';

/// Deja las preferencias a la mano de cualquier pantalla.
class SettingsScope extends InheritedNotifier<AppSettings> {
  const SettingsScope({
    super.key,
    required AppSettings settings,
    required super.child,
  }) : super(notifier: settings);

  static AppSettings of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<SettingsScope>();
    assert(scope != null, 'Falta SettingsScope arriba en el arbol');
    return scope!.notifier!;
  }
}

/// Dibuja la imagen de fondo (si hay una) detras de la pantalla. Cada pantalla
/// se envuelve con esto, asi las transiciones siguen viendose bien.
class AppBackground extends StatelessWidget {
  const AppBackground({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final settings = SettingsScope.of(context);
    final file = settings.backgroundImage;
    if (file == null) {
      if (!settings.liquidGlass) return child;
      // Sin imagen, el vidrio necesita algo de color detras para verse.
      final cs = Theme.of(context).colorScheme;
      return Stack(
        fit: StackFit.expand,
        children: [
          const ColoredBox(color: Colors.black),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.9, -0.85),
                radius: 1.2,
                colors: [cs.primary.withValues(alpha: 0.50), Colors.transparent],
              ),
            ),
          ),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(1.0, 0.1),
                radius: 1.1,
                colors: [cs.tertiary.withValues(alpha: 0.38), Colors.transparent],
              ),
            ),
          ),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.6, 1.0),
                radius: 1.1,
                colors: [cs.secondary.withValues(alpha: 0.34), Colors.transparent],
              ),
            ),
          ),
          child,
        ],
      );
    }
    return Stack(
      fit: StackFit.expand,
      children: [
        const ColoredBox(color: Colors.black),
        Image.file(
          file,
          key: ValueKey(file.path),
          fit: BoxFit.cover,
          cacheWidth: 1440,
          gaplessPlayback: true,
          errorBuilder: (context, error, stack) => const SizedBox.shrink(),
        ),
        ColoredBox(
          color: Colors.black.withValues(alpha: settings.backgroundDim),
        ),
        child,
      ],
    );
  }
}

/// Como un Scaffold, pero con la imagen de fondo (si hay) detras.
class AppScaffold extends StatelessWidget {
  const AppScaffold({
    super.key,
    this.appBar,
    this.body,
    this.floatingActionButton,
  });

  final PreferredSizeWidget? appBar;
  final Widget? body;
  final Widget? floatingActionButton;

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: Scaffold(
        appBar: appBar,
        body: body,
        floatingActionButton: floatingActionButton,
      ),
    );
  }
}
