import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'dsp.dart';

/// Guarda el analisis de estereo de cada cancion (unos 100 bytes cada una).
class StereoStore {
  static Future<File> _file() async {
    final dir = await getApplicationSupportDirectory();
    return File('${dir.path}/stereo_v1.json');
  }

  static Future<Map<String, StereoAnalysis>> load() async {
    final out = <String, StereoAnalysis>{};
    try {
      final f = await _file();
      if (!await f.exists()) return out;
      final json = jsonDecode(await f.readAsString()) as Map<String, dynamic>;
      for (final e in json.entries) {
        try {
          out[e.key] = StereoAnalysis.fromJson(
            Map<String, dynamic>.from(e.value as Map),
          );
        } catch (_) {}
      }
    } catch (_) {}
    return out;
  }

  static Future<void> save(Map<String, StereoAnalysis> items) async {
    try {
      final f = await _file();
      final tmp = File('${f.path}.tmp');
      await tmp.writeAsString(
        jsonEncode({for (final e in items.entries) e.key: e.value.toJson()}),
      );
      await tmp.rename(f.path);
    } catch (_) {}
  }

  static Future<void> clear() async {
    try {
      final f = await _file();
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }
}
