/// Volumenes objetivo de las plataformas (LUFS integrados). Valores publicados
/// en 2026 por las propias plataformas; pueden cambiar.
class LoudnessTarget {
  const LoudnessTarget(this.name, this.lufs, {this.note = ''});
  final String name;
  final double lufs;
  final String note;
}

const List<LoudnessTarget> kLoudnessTargets = [
  LoudnessTarget('Spotify', -14.0, note: 'Modo normal'),
  LoudnessTarget('Spotify Alto', -11.0, note: 'Opción "Alto" del usuario'),
  LoudnessTarget('Apple Music', -16.0, note: 'Sound Check'),
  LoudnessTarget('YouTube', -14.0, note: 'Solo baja, no sube'),
  LoudnessTarget('Tidal', -14.0),
  LoudnessTarget('Amazon Music', -14.0),
  LoudnessTarget('Deezer', -15.0),
];

/// Techo de pico real recomendado por las plataformas.
const double kTruePeakCeiling = -1.0;
