import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:isolate';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import 'codec.dart';
import 'dsp.dart';
import 'music_store.dart';
import 'stereo_store.dart';
import 'settings.dart';
import 'analyzer.dart';
import 'background.dart';
import 'audio_analysis_models.dart';
import 'store.dart';

const _audioExtensions = {
  '.flac', '.mp3', '.m4a', '.aac', '.opus', '.ogg', '.wav', '.wma', '.wv',
  '.ape', '.tta', '.aif', '.aiff', '.ac3', '.eac3', '.mka',
};

bool isAudioPath(String path) {
  final lower = path.toLowerCase();
  return _audioExtensions.any(lower.endsWith);
}

enum ItemState { waiting, running, done, error }

/// Valores especiales para elegir colecciones.
const String kNoCollection = '__none__'; // "Sin coleccion"
const String kAllCollections = '__all__'; // "Todas"

class Item {
  Item({
    required this.path,
    required this.size,
    required this.mtime,
    this.temp = false,
  });

  final String path;
  final int size;
  final int mtime;

  /// Archivo suelto (copia temporal): no se guarda en la biblioteca.
  final bool temp;

  ItemState state = ItemState.waiting;
  AudioAnalysisData? data;
  String? error;

  /// Coleccion a la que pertenece (null = sin coleccion).
  String? collection;

  String get name => path.split('/').last;
  String get cacheKey => SpectrogramCache.keyFor(path, size, mtime);
}

enum SortKey { name, dr, lufs, cutoff }

enum LibFilter { all, suspicious, compressed }

const _losslessCodecs = {'flac', 'alac', 'wavpack', 'ape', 'tta'};

/// Marca canciones lossless cuyo espectro sugiere un origen con perdida.
String? suspicionOf(AudioAnalysisData d) {
  final codec = d.codec.toLowerCase();
  final lossless = _losslessCodecs.contains(codec) || codec.startsWith('pcm_');
  if (!lossless) return null;
  final cutoff = d.spectralCutoffHz;
  if (cutoff == null) return null;
  if (d.sampleRate > 48000 && cutoff < 23000) {
    return 'Posible upsample (corte en ${(cutoff / 1000).toStringAsFixed(1)} kHz)';
  }
  if (cutoff < 19000) {
    return 'Posible transcode de MP3/AAC (corte en ${(cutoff / 1000).toStringAsFixed(1)} kHz)';
  }
  return null;
}

bool isCompressed(AudioAnalysisData d) => d.dynamicRange < 8;

class LibrarySummary {
  const LibrarySummary({
    required this.analyzed,
    required this.avgDr,
    required this.avgLufs,
    required this.suspicious,
  });
  final int analyzed;
  final double? avgDr;
  final double? avgLufs;
  final int suspicious;
}

class LibraryController extends ChangeNotifier {
  LibraryController(this.settings);

  final AppSettings settings;
  final Analyzer analyzer = Analyzer();
  final Map<String, Item> _items = {};
  final List<Item> _queue = [];
  final Map<String, MusicAnalysis> _music = {};
  final Map<String, StereoAnalysis> _stereo = {};
  int _active = 0;
  bool _saving = false;

  bool running = false;
  bool scanning = false;
  int runTotal = 0;
  int runDone = 0;
  String? currentName;
  bool _stop = false;
  int _unsaved = 0;

  Future<void> init() async {
    final stored = await ResultsStore.load();
    for (final e in stored.entries) {
      _items[e.key] = Item(
        path: e.key,
        size: e.value.size,
        mtime: e.value.mtime,
      )
        ..data = e.value.data
        ..collection = e.value.collection
        ..state = ItemState.done;
    }
    _music.addAll(await MusicStore.load());
    _stereo.addAll(await StereoStore.load());
    try {
      await FilePicker.platform.clearTemporaryFiles();
    } catch (_) {}
    notifyListeners();
  }

  /// BPM, tonalidad y balance ya calculados de esta cancion (o null).
  MusicAnalysis? musicFor(Item item) => _music[item.cacheKey];

  /// Analisis de estereo ya calculado de esta cancion (o null).
  StereoAnalysis? stereoFor(Item item) => _stereo[item.cacheKey];

  /// Calcula el estereo. Devuelve null si la cancion es mono.
  Future<StereoAnalysis?> computeStereo(Item item, {bool force = false}) async {
    final cached = _stereo[item.cacheKey];
    if (cached != null && !force) return cached;
    final m = await analyzer.analyzeStereo(item.path, item.data!.duration);
    if (m != null) {
      _stereo[item.cacheKey] = m;
      await StereoStore.save(_stereo);
      notifyListeners();
    }
    return m;
  }

  /// Calcula (o recupera de la cache) el analisis musical de una cancion.
  Future<MusicAnalysis> computeMusic(Item item, {bool force = false}) async {
    final cached = _music[item.cacheKey];
    if (cached != null && !force) return cached;
    final m = await analyzer.analyzeMusic(item.path, item.data!.duration);
    _music[item.cacheKey] = m;
    await MusicStore.save(_music);
    notifyListeners();
    return m;
  }

  int get totalItems => _items.length;

  /// Canciones ya analizadas (para duplicados y comparar).
  List<Item> get analyzedItems => _items.values
      .where((i) => i.state == ItemState.done && i.data != null)
      .toList();

  /// Agrega archivos a la cola. Devuelve cuantos se van a analizar.
  Future<int> addPaths(
    Iterable<String> paths, {
    bool temp = false,
    String? collection,
  }) async {
    final target = collection == kNoCollection ? null : collection;
    var added = 0;
    for (final p in paths) {
      if (!isAudioPath(p)) continue;
      try {
        final st = await File(p).stat();
        if (st.type != FileSystemEntityType.file) continue;
        final mtime = st.modified.millisecondsSinceEpoch;
        final existing = _items[p];
        if (existing != null) {
          if (existing.state == ItemState.waiting ||
              existing.state == ItemState.running) {
            continue;
          }
          if (existing.state == ItemState.done &&
              existing.size == st.size &&
              existing.mtime == mtime) {
            // Ya estaba analizada: solo se actualiza su coleccion si se pidio.
            if (collection != null && !temp && existing.collection != target) {
              existing.collection = target;
              _unsaved++;
            }
            continue;
          }
        }
        final item = Item(path: p, size: st.size, mtime: mtime, temp: temp);
        if (!temp) item.collection = target;
        _items[p] = item;
        _queue.add(item);
        added++;
      } catch (_) {}
    }
    notifyListeners();
    if (added > 0) unawaited(_runQueue());
    return added;
  }

  /// Busca audio dentro de una carpeta (con subcarpetas).
  Future<({int found, int added})> addFolder(
    String dir, {
    String? collection,
  }) async {
    scanning = true;
    notifyListeners();
    final found = <String>[];
    try {
      final stream = Directory(
        dir,
      ).list(recursive: true, followLinks: false).handleError((_) {});
      await for (final e in stream) {
        if (e is File && isAudioPath(e.path)) found.add(e.path);
      }
    } catch (_) {}
    scanning = false;
    final added = await addPaths(found, collection: collection);
    if (_unsaved > 0 && !running) await _save();
    return (found: found.length, added: added);
  }

  Future<void> _runQueue() async {
    if (running) return;
    running = true;
    _stop = false;
    _active = 0;
    runTotal = _queue.length;
    runDone = 0;
    var cancelled = false;
    var okCount = 0;
    var errCount = 0;
    await BackgroundService.start(
      title: 'Analizando canciones…',
      text: '',
      progress: 0,
      max: runTotal,
    );
    notifyListeners();

    Future<void> worker() async {
      while (!_stop && _queue.isNotEmpty) {
        final item = _queue.removeAt(0);
        item.state = ItemState.running;
        currentName = item.name;
        _active++;
        runTotal = runDone + _queue.length + _active;
        notifyListeners();
        unawaited(
          BackgroundService.update(
            title: 'Analizando ${runDone + 1} de $runTotal',
            text: item.name,
            progress: runDone,
            max: runTotal,
          ),
        );
        try {
          final d = await analyzer.analyze(item.path);
          item.data = d;
          item.error = null;
          item.state = ItemState.done;
          okCount++;
          if (!item.temp) _unsaved++;
        } catch (e) {
          if (_stop) {
            if (item.data == null) {
              _items.remove(item.path);
            } else {
              item.state = ItemState.done;
            }
            _active--;
            return;
          }
          item.error = e.toString().replaceFirst('Exception: ', '');
          item.state = ItemState.error;
          errCount++;
        }
        _active--;
        runDone++;
        notifyListeners();
        if (_unsaved >= 25) await _save();
      }
    }

    try {
      final threads = settings.analysisThreads.clamp(1, 3).toInt();
      do {
        await Future.wait(List.generate(threads, (_) => worker()));
      } while (!_stop && _queue.isNotEmpty);
      if (_stop) {
        cancelled = true;
        for (final item in _queue) {
          if (item.data == null) _items.remove(item.path);
        }
        _queue.clear();
      }
    } finally {
      running = false;
      currentName = null;
      _active = 0;
      await _save();
      if (cancelled) {
        await BackgroundService.stop();
      } else {
        await BackgroundService.finish(
          title: 'Análisis terminado',
          text:
              '${okCount == 1 ? '1 canción analizada' : '$okCount canciones analizadas'}'
              '${errCount > 0 ? ' · $errCount con error' : ''}',
        );
      }
      notifyListeners();
    }
  }

  Future<void> stop() async {
    _stop = true;
    notifyListeners();
    await analyzer.cancelAll();
  }

  /// Reanaliza una cancion ahora mismo (sin pasar por la cola).
  Future<bool> reanalyze(Item item) async {
    final previous = item.state;
    item.state = ItemState.running;
    notifyListeners();
    try {
      item.data = await analyzer.analyze(item.path);
      item.error = null;
      item.state = ItemState.done;
      if (!item.temp) await _save();
      notifyListeners();
      return true;
    } catch (e) {
      item.error = e.toString().replaceFirst('Exception: ', '');
      item.state = item.data != null ? ItemState.done : previous;
      notifyListeners();
      return false;
    }
  }

  /// Reintenta una cancion con error.
  Future<void> retry(Item item) async {
    if (item.state != ItemState.error) return;
    item.state = ItemState.waiting;
    _queue.add(item);
    notifyListeners();
    unawaited(_runQueue());
  }

  bool _savePending = false;

  Future<void> _save() async {
    if (_saving) {
      _savePending = true;
      return;
    }
    _saving = true;
    try {
      do {
        _savePending = false;
        await _saveNow();
      } while (_savePending);
    } finally {
      _saving = false;
    }
  }

  Future<void> _saveNow() async {
    final map = <String, StoredResult>{};
    for (final i in _items.values) {
      if (i.temp || i.state != ItemState.done || i.data == null) continue;
      map[i.path] = StoredResult(
        data: i.data!,
        size: i.size,
        mtime: i.mtime,
        collection: i.collection,
      );
    }
    _unsaved = 0;
    await ResultsStore.save(map);
  }

  Future<void> clearAll() async {
    if (running) return;
    _items.clear();
    _music.clear();
    _stereo.clear();
    await ResultsStore.clear();
    await MusicStore.clear();
    await StereoStore.clear();
    notifyListeners();
  }

  // ---------------------------------------------------------------------
  // Colecciones
  // ---------------------------------------------------------------------

  bool _inCollection(Item i, String? c) {
    if (c == null) return true;
    if (c == kNoCollection) return i.collection == null;
    return i.collection == c;
  }

  /// Nombres de colecciones (las creadas y las que alguna cancion usa).
  List<String> get collectionNames {
    final set = <String>{...settings.collections};
    for (final i in _items.values) {
      final c = i.collection;
      if (c != null) set.add(c);
    }
    return set.toList()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
  }

  /// Canciones analizadas en una coleccion (null = todas).
  int countInCollection(String? c) => _items.values
      .where((i) => i.state == ItemState.done && _inCollection(i, c))
      .length;

  Future<void> createCollection(String name) async {
    final n = name.trim();
    if (n.isEmpty || n == kNoCollection || n == kAllCollections) return;
    final exists = collectionNames.any((c) => c.toLowerCase() == n.toLowerCase());
    if (!exists) settings.setCollections([...settings.collections, n]);
    notifyListeners();
  }

  Future<void> renameCollection(String old, String name) async {
    final n = name.trim();
    if (n.isEmpty || n == old || n == kNoCollection || n == kAllCollections) {
      return;
    }
    for (final i in _items.values) {
      if (i.collection == old) i.collection = n;
    }
    final list = settings.collections.map((c) => c == old ? n : c).toSet();
    list.add(n);
    settings.setCollections(list.toList());
    await _save();
    notifyListeners();
  }

  Future<void> deleteCollection(String name) async {
    for (final i in _items.values) {
      if (i.collection == name) i.collection = null;
    }
    settings.setCollections(
      settings.collections.where((c) => c != name).toList(),
    );
    await _save();
    notifyListeners();
  }

  Future<void> setItemCollection(Item item, String? name) async {
    item.collection = name;
    if (name != null && !settings.collections.contains(name)) {
      settings.setCollections([...settings.collections, name]);
    }
    if (!item.temp) await _save();
    notifyListeners();
  }

  // ---------------------------------------------------------------------
  // Canciones compartidas desde otras apps
  // ---------------------------------------------------------------------

  /// Analiza una cancion ahora mismo (sin pasar por la cola). Es temporal:
  /// no se guarda en la biblioteca.
  Future<Item?> analyzeNow(String path) async {
    try {
      final st = await File(path).stat();
      if (st.type != FileSystemEntityType.file) return null;
      final item = Item(
        path: path,
        size: st.size,
        mtime: st.modified.millisecondsSinceEpoch,
        temp: true,
      );
      item.state = ItemState.running;
      _items[path] = item;
      notifyListeners();
      try {
        item.data = await analyzer.analyze(path);
        item.state = ItemState.done;
      } catch (e) {
        item.error = e.toString().replaceFirst('Exception: ', '');
        item.state = ItemState.error;
      }
      notifyListeners();
      return item;
    } catch (_) {
      return null;
    }
  }

  // ---------------------------------------------------------------------
  // Respaldo
  // ---------------------------------------------------------------------

  /// Escribe un archivo de respaldo con todos los resultados y devuelve su ruta.
  Future<String?> exportBackup() async {
    final results = <String, dynamic>{};
    for (final i in _items.values) {
      if (i.temp || i.state != ItemState.done || i.data == null) continue;
      results[i.path] = {
        'size': i.size,
        'mtime': i.mtime,
        'collection': i.collection,
        'data': i.data!.toJson(),
      };
    }
    if (results.isEmpty) return null;
    final payload = <String, dynamic>{
      'format': 'aztra-backup',
      'v': 1,
      'results': results,
      'music': {for (final e in _music.entries) e.key: e.value.toJson()},
      'stereo': {for (final e in _stereo.entries) e.key: e.value.toJson()},
      'collections': collectionNames,
    };
    final text = await Isolate.run(() => jsonEncode(payload));
    final tmp = await getTemporaryDirectory();
    final now = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    final f = File(
      '${tmp.path}/aztra_respaldo_${now.year}${two(now.month)}${two(now.day)}.json',
    );
    await f.writeAsString(text);
    return f.path;
  }

  /// Mezcla un respaldo con la biblioteca. Devuelve cuantas canciones leyo, o
  /// -1 si el archivo no es un respaldo valido.
  Future<int> importBackup(String path) async {
    try {
      final text = await File(path).readAsString();
      final json = await Isolate.run(() => jsonDecode(text));
      if (json is! Map || json['format'] != 'aztra-backup') return -1;
      var count = 0;
      final results = json['results'];
      if (results is Map) {
        for (final e in results.entries) {
          try {
            final m = Map<String, dynamic>.from(e.value as Map);
            final dataJson = Map<String, dynamic>.from(m['data'] as Map);
            if (dataJson['cacheVersion'] != AudioAnalysisData.cacheVersion) {
              continue;
            }
            final p = e.key as String;
            final existing = _items[p];
            if (existing != null &&
                (existing.state == ItemState.running ||
                    existing.state == ItemState.waiting)) {
              continue;
            }
            _items[p] = Item(
              path: p,
              size: m['size'] as int,
              mtime: m['mtime'] as int,
            )
              ..data = AudioAnalysisData.fromJson(dataJson)
              ..collection = m['collection'] as String?
              ..state = ItemState.done;
            count++;
          } catch (_) {}
        }
      }
      final music = json['music'];
      if (music is Map) {
        for (final e in music.entries) {
          try {
            _music[e.key as String] = MusicAnalysis.fromJson(
              Map<String, dynamic>.from(e.value as Map),
            );
          } catch (_) {}
        }
      }
      final stereo = json['stereo'];
      if (stereo is Map) {
        for (final e in stereo.entries) {
          try {
            _stereo[e.key as String] = StereoAnalysis.fromJson(
              Map<String, dynamic>.from(e.value as Map),
            );
          } catch (_) {}
        }
      }
      final cols = json['collections'];
      if (cols is List) {
        final names = <String>{...settings.collections};
        names.addAll(cols.whereType<String>());
        settings.setCollections(names.toList());
      }
      await _save();
      await MusicStore.save(_music);
      await StereoStore.save(_stereo);
      notifyListeners();
      return count;
    } catch (_) {
      return -1;
    }
  }

  LibrarySummary summary({String? collection}) {
    var n = 0;
    var drSum = 0.0;
    var lufsSum = 0.0;
    var lufsN = 0;
    var sus = 0;
    for (final i in _items.values) {
      final d = i.data;
      if (i.state != ItemState.done || d == null) continue;
      if (!_inCollection(i, collection)) continue;
      n++;
      drSum += d.dynamicRange;
      if (d.integratedLufs != null) {
        lufsSum += d.integratedLufs!;
        lufsN++;
      }
      if (suspicionOf(d) != null) sus++;
    }
    return LibrarySummary(
      analyzed: n,
      avgDr: n > 0 ? drSum / n : null,
      avgLufs: lufsN > 0 ? lufsSum / lufsN : null,
      suspicious: sus,
    );
  }

  /// Cuantas canciones analizadas hay de cada formato (FLAC, MP3, WAV, Otros).
  Map<String, int> formatCounts({String? collection}) {
    final counts = <String, int>{};
    for (final i in _items.values) {
      final d = i.data;
      if (i.state != ItemState.done || d == null) continue;
      if (!_inCollection(i, collection)) continue;
      final g = formatGroup(d);
      counts[g] = (counts[g] ?? 0) + 1;
    }
    return counts;
  }

  /// Cuantas canciones hay de cada profundidad de bits (0 = sin dato).
  Map<int, int> bitCounts({String? collection}) {
    final counts = <int, int>{};
    for (final i in _items.values) {
      final d = i.data;
      if (i.state != ItemState.done || d == null) continue;
      if (!_inCollection(i, collection)) continue;
      final b = d.bitsPerSample > 0 ? d.bitsPerSample : 0;
      counts[b] = (counts[b] ?? 0) + 1;
    }
    return counts;
  }

  /// Cuantas canciones hay de cada frecuencia de muestreo (en Hz).
  Map<int, int> rateCounts({String? collection}) {
    final counts = <int, int>{};
    for (final i in _items.values) {
      final d = i.data;
      if (i.state != ItemState.done || d == null) continue;
      if (!_inCollection(i, collection)) continue;
      counts[d.sampleRate] = (counts[d.sampleRate] ?? 0) + 1;
    }
    return counts;
  }

  List<Item> view({
    String query = '',
    LibFilter filter = LibFilter.all,
    String? format,
    int? bits,
    int? rate,
    String? collection,
    SortKey sort = SortKey.name,
    bool ascending = true,
  }) {
    final q = query.trim().toLowerCase();
    final list = _items.values.where((i) {
      if (q.isNotEmpty && !i.name.toLowerCase().contains(q)) return false;
      if (!_inCollection(i, collection)) return false;
      final d = i.data;
      if (format != null) {
        if (d == null || formatGroup(d) != format) return false;
      }
      if (bits != null) {
        if (d == null || (d.bitsPerSample > 0 ? d.bitsPerSample : 0) != bits) {
          return false;
        }
      }
      if (rate != null) {
        if (d == null || d.sampleRate != rate) return false;
      }
      if (filter == LibFilter.all) return true;
      if (d == null) return false;
      if (filter == LibFilter.suspicious) return suspicionOf(d) != null;
      return isCompressed(d);
    }).toList();

    int cmpNum(double? a, double? b) {
      if (a == null && b == null) return 0;
      if (a == null) return 1; // sin dato siempre al final
      if (b == null) return -1;
      return ascending ? a.compareTo(b) : b.compareTo(a);
    }

    list.sort((a, b) {
      switch (sort) {
        case SortKey.name:
          final c = a.name.toLowerCase().compareTo(b.name.toLowerCase());
          return ascending ? c : -c;
        case SortKey.dr:
          return cmpNum(a.data?.dynamicRange, b.data?.dynamicRange);
        case SortKey.lufs:
          return cmpNum(a.data?.integratedLufs, b.data?.integratedLufs);
        case SortKey.cutoff:
          return cmpNum(a.data?.spectralCutoffHz, b.data?.spectralCutoffHz);
      }
    });
    return list;
  }

  static String _csv(Object? v) {
    final s = v?.toString() ?? '';
    if (s.contains(',') || s.contains('"') || s.contains('\n')) {
      return '"${s.replaceAll('"', '""')}"';
    }
    return s;
  }

  /// Escribe un CSV con todos los resultados y devuelve su ruta.
  Future<String?> exportCsv() async {
    final rows = _items.values
        .where((i) => i.state == ItemState.done && i.data != null)
        .toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    if (rows.isEmpty) return null;
    final b = StringBuffer('\uFEFF');
    b.writeln(
      'archivo,ruta,codec,frecuencia_hz,bits,bitrate_kbps,canales,duracion_s,'
      'tamano_bytes,rango_dinamico_db,pico_db,rms_db,lufs,pico_real_dbtp,'
      'recorte_muestras,corte_espectral_hz,aviso,bpm,tonalidad,coleccion',
    );
    for (final i in rows) {
      final d = i.data!;
      b.writeln(
        [
          i.name,
          i.path,
          codecLabel(d),
          d.sampleRate,
          d.bitDepth,
          (d.bitrate / 1000).round(),
          d.channels,
          d.duration.toStringAsFixed(1),
          d.fileSize,
          d.dynamicRange.toStringAsFixed(2),
          d.peakAmplitude.toStringAsFixed(2),
          d.rmsLevel.toStringAsFixed(2),
          d.integratedLufs?.toStringAsFixed(1),
          d.truePeakDb?.toStringAsFixed(2),
          d.clippingSamples,
          d.spectralCutoffHz?.toStringAsFixed(0),
          suspicionOf(d),
          musicFor(i)?.bpm?.toStringAsFixed(1),
          musicFor(i)?.keyLabel,
          i.collection,
        ].map(_csv).join(','),
      );
    }
    final tmp = await getTemporaryDirectory();
    final now = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    final stamp = '${now.year}${two(now.month)}${two(now.day)}';
    final f = File('${tmp.path}/aztra_analyzer_$stamp.csv');
    await f.writeAsString(b.toString());
    return f.path;
  }
}
