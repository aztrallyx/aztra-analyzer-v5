import 'package:flutter/material.dart';

import 'glass.dart';
import 'audio_analysis_models.dart';
import 'loudness_targets.dart';

/// Cuanto ajustaria cada plataforma el volumen de esta cancion.
class PlatformsCard extends StatelessWidget {
  const PlatformsCard({super.key, required this.data});

  final AudioAnalysisData data;

  @override
  Widget build(BuildContext context) {
    final lufs = data.integratedLufs;
    if (lufs == null) return const SizedBox.shrink();
    final cs = Theme.of(context).colorScheme;
    final tp = data.truePeakDb;

    TextStyle label = TextStyle(color: cs.onSurfaceVariant, fontSize: 12);
    const value = TextStyle(fontSize: 12, fontWeight: FontWeight.w600);

    Widget row(LoudnessTarget t) {
      final gain = t.lufs - lufs;
      String adjust;
      if (gain.abs() < 0.1) {
        adjust = 'Sin cambio';
      } else if (gain < 0) {
        adjust = '${gain.toStringAsFixed(1)} dB';
      } else {
        adjust = '+${gain.toStringAsFixed(1)} dB';
      }
      String status;
      if (gain < -0.1) {
        status = 'La baja';
      } else if (gain > 0.1) {
        status = 'Queda más baja';
      } else {
        status = 'Justo';
      }
      final tpAfter = (tp != null && gain > 0) ? tp + gain : null;
      final overTp = tpAfter != null && tpAfter > kTruePeakCeiling;
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(flex: 5, child: Text(t.name, style: value)),
                Expanded(
                  flex: 3,
                  child: Text('${t.lufs.toStringAsFixed(0)} LUFS', style: label),
                ),
                Expanded(
                  flex: 3,
                  child: Text(adjust, style: value, textAlign: TextAlign.end),
                ),
              ],
            ),
            Row(
              children: [
                Expanded(
                  child: Text(
                    overTp
                        ? '$status · el pico real quedaría en ${tpAfter!.toStringAsFixed(1)} dBTP (sobre ${kTruePeakCeiling.toStringAsFixed(0)})'
                        : status,
                    style: TextStyle(
                      color: overTp ? cs.error : cs.onSurfaceVariant,
                      fontSize: 11,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    }

    return GlassPanel(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Volumen por plataforma',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 4),
            Text(
              'Esta canción está en ${lufs.toStringAsFixed(1)} LUFS'
              '${tp == null ? '' : ' con pico real de ${tp.toStringAsFixed(2)} dBTP'}.',
              style: label,
            ),
            const SizedBox(height: 8),
            for (final t in kLoudnessTargets) row(t),
            const SizedBox(height: 6),
            Text(
              'Objetivos publicados por las plataformas (pico real máximo de '
              '${kTruePeakCeiling.toStringAsFixed(0)} dBTP); pueden cambiar. La '
              'plataforma ajusta al reproducir, tu archivo no cambia. TikTok y '
              'SoundCloud no publican un objetivo oficial.',
              style: TextStyle(color: cs.onSurfaceVariant, fontSize: 11),
            ),
          ],
        ),
      ),
    );
  }
}
