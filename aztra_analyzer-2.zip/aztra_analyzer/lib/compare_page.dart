import 'package:flutter/material.dart';

import 'glass.dart';
import 'codec.dart';
import 'dsp.dart';
import 'app_background.dart';
import 'audio_analysis_ffmpeg.dart';
import 'audio_analysis_models.dart';
import 'format.dart';
import 'library.dart';
import 'pick_song_page.dart';
import 'settings.dart';
import 'spectrogram_panel.dart';

/// Compara dos canciones ya analizadas: numeros lado a lado, un resumen en
/// palabras y los dos espectrogramas.
class ComparePage extends StatefulWidget {
  const ComparePage({
    super.key,
    required this.controller,
    required this.settings,
    this.a,
    this.b,
  });

  final LibraryController controller;
  final AppSettings settings;
  final Item? a;
  final Item? b;

  @override
  State<ComparePage> createState() => _ComparePageState();
}

class _ComparePageState extends State<ComparePage> {
  Item? _a;
  Item? _b;

  @override
  void initState() {
    super.initState();
    _a = widget.a;
    _b = widget.b;
  }

  Future<void> _pick(bool isA) async {
    final picked = await Navigator.of(context).push<Item>(
      MaterialPageRoute(
        builder: (_) => PickSongPage(
          controller: widget.controller,
          title: isA ? 'Elegir canción A' : 'Elegir canción B',
        ),
      ),
    );
    if (picked == null || !mounted) return;
    setState(() {
      if (isA) {
        _a = picked;
      } else {
        _b = picked;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final a = _a;
    final b = _b;
    return AppScaffold(
      appBar: AppBar(title: const Text('Comparar')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          Row(
            children: [
              Expanded(
                child: _Slot(label: 'A', item: a, onTap: () => _pick(true)),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _Slot(label: 'B', item: b, onTap: () => _pick(false)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (a == null || b == null)
            Padding(
              padding: const EdgeInsets.all(24),
              child: Text(
                'Elige dos canciones ya analizadas para compararlas.',
                textAlign: TextAlign.center,
                style: TextStyle(color: cs.onSurfaceVariant),
              ),
            )
          else ...[
            _InsightsCard(a: a.data!, b: b.data!),
            const SizedBox(height: 12),
            _TableCard(a: a.data!, b: b.data!),
            const SizedBox(height: 12),
            _MusicCompareCard(
              key: ValueKey('music-${a.path}-${b.path}'),
              a: a,
              b: b,
              controller: widget.controller,
            ),
            const SizedBox(height: 16),
            _Label('A · ${a.name}'),
            SpectrogramPanel(
              key: ValueKey('spec-a-${a.path}'),
              item: a,
              controller: widget.controller,
              settings: widget.settings,
            ),
            const SizedBox(height: 16),
            _Label('B · ${b.name}'),
            SpectrogramPanel(
              key: ValueKey('spec-b-${b.path}'),
              item: b,
              controller: widget.controller,
              settings: widget.settings,
            ),
          ],
        ],
      ),
    );
  }
}

class _Label extends StatelessWidget {
  const _Label(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 0, 4, 6),
      child: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
      ),
    );
  }
}

class _Slot extends StatelessWidget {
  const _Slot({required this.label, required this.item, required this.onTap});
  final String label;
  final Item? item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return GlassPanel(
        child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Canción $label',
                style: TextStyle(
                  color: cs.primary,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                item?.name ?? 'Toca para elegir',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 13,
                  color: item == null ? cs.onSurfaceVariant : cs.onSurface,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

String _kHz(double? hz) =>
    hz == null ? 'No detectado' : '${(hz / 1000).toStringAsFixed(1)} kHz';

List<String> _insights(AudioAnalysisData a, AudioAnalysisData b) {
  final out = <String>[];

  final dr = b.dynamicRange - a.dynamicRange;
  if (dr.abs() >= 0.5) {
    out.add(
      '${dr > 0 ? 'B' : 'A'} tiene ${dr.abs().toStringAsFixed(1)} dB más de '
      'rango dinámico (suena menos comprimida).',
    );
  } else {
    out.add('El rango dinámico es casi igual (diferencia de ${dr.abs().toStringAsFixed(1)} dB).');
  }

  final la = a.integratedLufs;
  final lb = b.integratedLufs;
  if (la != null && lb != null) {
    final d = lb - la;
    if (d.abs() >= 0.5) {
      out.add(
        '${d > 0 ? 'B' : 'A'} suena ${d.abs().toStringAsFixed(1)} dB más fuerte '
        '(LUFS). Ojo: si no igualas el volumen, la más fuerte suele parecer mejor.',
      );
    } else {
      out.add('El volumen (LUFS) es casi igual.');
    }
  }

  final ca = a.spectralCutoffHz;
  final cb = b.spectralCutoffHz;
  if (ca != null && cb != null && (ca - cb).abs() >= 1000) {
    out.add(
      'El corte espectral cambia: A llega hasta ${_kHz(ca)} y B hasta ${_kHz(cb)}.',
    );
  }

  if (a.sampleRate != b.sampleRate || a.bitDepth != b.bitDepth) {
    out.add(
      'Formato distinto: A es ${codecLabel(a)} ${(a.sampleRate / 1000).toStringAsFixed(1)} kHz '
      '${a.bitDepth}, B es ${codecLabel(b)} ${(b.sampleRate / 1000).toStringAsFixed(1)} kHz ${b.bitDepth}.',
    );
  }

  if ((a.clippingSamples > 0) != (b.clippingSamples > 0)) {
    out.add('${a.clippingSamples > 0 ? 'A' : 'B'} tiene recortes y la otra no.');
  }

  if ((a.duration - b.duration).abs() >= 1) {
    out.add(
      'Duran distinto: A ${formatClock(a.duration)} y B ${formatClock(b.duration)}.',
    );
  }
  return out;
}

class _InsightsCard extends StatelessWidget {
  const _InsightsCard({required this.a, required this.b});
  final AudioAnalysisData a;
  final AudioAnalysisData b;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final lines = _insights(a, b);
    return GlassPanel(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Resumen',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            for (final l in lines)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 6, right: 8),
                      child: Container(
                        width: 5,
                        height: 5,
                        decoration: BoxDecoration(
                          color: cs.primary,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                    Expanded(child: Text(l, style: const TextStyle(fontSize: 13))),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _TableCard extends StatelessWidget {
  const _TableCard({required this.a, required this.b});
  final AudioAnalysisData a;
  final AudioAnalysisData b;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    String delta(double? x, double? y, String unit, {int digits = 1}) {
      if (x == null || y == null) return '';
      final d = y - x;
      if (d.abs() < 0.05) return '=';
      return '${d > 0 ? '+' : ''}${d.toStringAsFixed(digits)} $unit';
    }

    final rows = <List<String>>[
      ['Códec', codecLabel(a), codecLabel(b), ''],
      [
        'Frecuencia',
        '${(a.sampleRate / 1000).toStringAsFixed(1)} kHz',
        '${(b.sampleRate / 1000).toStringAsFixed(1)} kHz',
        '',
      ],
      ['Bits', a.bitDepth, b.bitDepth, ''],
      [
        'Tasa de bits',
        '${(a.bitrate / 1000).round()} kbps',
        '${(b.bitrate / 1000).round()} kbps',
        '',
      ],
      ['Duración', formatClock(a.duration), formatClock(b.duration), ''],
      ['Tamaño', formatBytes(a.fileSize), formatBytes(b.fileSize), ''],
      [
        'Rango dinámico',
        '${a.dynamicRange.toStringAsFixed(2)} dB',
        '${b.dynamicRange.toStringAsFixed(2)} dB',
        delta(a.dynamicRange, b.dynamicRange, 'dB'),
      ],
      [
        'Pico',
        '${a.peakAmplitude.toStringAsFixed(2)} dB',
        '${b.peakAmplitude.toStringAsFixed(2)} dB',
        delta(a.peakAmplitude, b.peakAmplitude, 'dB'),
      ],
      [
        'RMS',
        '${a.rmsLevel.toStringAsFixed(2)} dB',
        '${b.rmsLevel.toStringAsFixed(2)} dB',
        delta(a.rmsLevel, b.rmsLevel, 'dB'),
      ],
      [
        'LUFS',
        a.integratedLufs == null ? '—' : a.integratedLufs!.toStringAsFixed(1),
        b.integratedLufs == null ? '—' : b.integratedLufs!.toStringAsFixed(1),
        delta(a.integratedLufs, b.integratedLufs, 'LU'),
      ],
      [
        'Pico real',
        a.truePeakDb == null ? '—' : '${a.truePeakDb!.toStringAsFixed(2)} dBTP',
        b.truePeakDb == null ? '—' : '${b.truePeakDb!.toStringAsFixed(2)} dBTP',
        delta(a.truePeakDb, b.truePeakDb, 'dB', digits: 2),
      ],
      [
        'Recorte',
        a.clippingSamples <= 0 ? 'Sin recortes' : formatCount(a.clippingSamples),
        b.clippingSamples <= 0 ? 'Sin recortes' : formatCount(b.clippingSamples),
        '',
      ],
      [
        'Corte espectral',
        formatAudioAnalysisSpectralCutoff(
          a.spectralCutoffHz,
          notDetectedLabel: 'No detectado',
        ),
        formatAudioAnalysisSpectralCutoff(
          b.spectralCutoffHz,
          notDetectedLabel: 'No detectado',
        ),
        '',
      ],
    ];

    TextStyle head = TextStyle(
      color: cs.primary,
      fontSize: 12,
      fontWeight: FontWeight.w600,
    );
    TextStyle label = TextStyle(color: cs.onSurfaceVariant, fontSize: 12);
    const value = TextStyle(fontSize: 12, fontWeight: FontWeight.w600);

    return GlassPanel(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
        child: Column(
          children: [
            Row(
              children: [
                const Expanded(flex: 4, child: SizedBox()),
                Expanded(flex: 4, child: Text('A', style: head)),
                Expanded(flex: 4, child: Text('B', style: head)),
                Expanded(
                  flex: 3,
                  child: Text('B − A', style: head, textAlign: TextAlign.end),
                ),
              ],
            ),
            const SizedBox(height: 6),
            for (final r in rows)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: Row(
                  children: [
                    Expanded(flex: 4, child: Text(r[0], style: label)),
                    Expanded(flex: 4, child: Text(r[1], style: value)),
                    Expanded(flex: 4, child: Text(r[2], style: value)),
                    Expanded(
                      flex: 3,
                      child: Text(
                        r[3],
                        style: label,
                        textAlign: TextAlign.end,
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}


class _MusicCompareCard extends StatefulWidget {
  const _MusicCompareCard({
    super.key,
    required this.a,
    required this.b,
    required this.controller,
  });

  final Item a;
  final Item b;
  final LibraryController controller;

  @override
  State<_MusicCompareCard> createState() => _MusicCompareCardState();
}

class _MusicCompareCardState extends State<_MusicCompareCard> {
  bool _busy = false;
  String? _error;

  Future<void> _run() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      // Una tras otra, para no cargar de mas el telefono.
      await widget.controller.computeMusic(widget.a);
      await widget.controller.computeMusic(widget.b);
    } catch (e) {
      _error = e.toString().replaceFirst('Exception: ', '');
    }
    if (!mounted) return;
    setState(() => _busy = false);
  }

  /// Bandas respecto a los medios, para que el volumen general no estorbe.
  static List<double>? _anchored(MusicAnalysis? m) {
    final b = m?.bandsDb;
    if (b == null || b.length != 7) return null;
    return [for (final v in b) v - b[kBandAnchor]];
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final ma = widget.controller.musicFor(widget.a);
    final mb = widget.controller.musicFor(widget.b);
    final aa = _anchored(ma);
    final ab = _anchored(mb);

    return GlassPanel(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Balance de frecuencias, ritmo y tonalidad',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            if (_busy) ...[
              const LinearProgressIndicator(minHeight: 2),
              const SizedBox(height: 8),
              Text(
                'Analizando las dos canciones… tarda unos segundos.',
                style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
              ),
            ] else if (ma == null || mb == null) ...[
              Text(
                'Compara cómo se reparte la energía entre graves, medios y '
                'agudos (con el mismo volumen), y detecta BPM y tonalidad.',
                style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
              ),
              const SizedBox(height: 10),
              FilledButton.tonal(
                onPressed: _run,
                child: const Text('Analizar las dos'),
              ),
              if (_error != null) ...[
                const SizedBox(height: 8),
                Text(_error!, style: TextStyle(color: cs.error, fontSize: 12)),
              ],
            ] else ...[
              _pairLine(
                cs,
                'BPM',
                ma.bpm == null ? '—' : formatBpm(ma.bpm!),
                mb.bpm == null ? '—' : formatBpm(mb.bpm!),
              ),
              _pairLine(
                cs,
                'Tonalidad',
                ma.keyLabel ?? '—',
                mb.keyLabel ?? '—',
              ),
              const SizedBox(height: 10),
              if (aa != null && ab != null) ...[
                Text(
                  'B − A, tomando los medios como referencia',
                  style: TextStyle(color: cs.onSurfaceVariant, fontSize: 11),
                ),
                const SizedBox(height: 6),
                for (var i = 0; i < 7; i++)
                  _bandRow(cs, i, ab[i] - aa[i]),
                const SizedBox(height: 8),
                Text(
                  _summary(aa, ab),
                  style: const TextStyle(fontSize: 13),
                ),
              ] else
                Text(
                  'No se pudo medir el balance de alguna de las dos.',
                  style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
                ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _pairLine(ColorScheme cs, String label, String a, String b) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Expanded(
            flex: 4,
            child: Text(
              label,
              style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
            ),
          ),
          Expanded(
            flex: 4,
            child: Text(
              a,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
            ),
          ),
          Expanded(
            flex: 4,
            child: Text(
              b,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Widget _bandRow(ColorScheme cs, int i, double delta) {
    final isAnchor = i == kBandAnchor;
    final text = isAnchor
        ? 'ref.'
        : (delta.abs() < 0.05
              ? '='
              : '${delta > 0 ? '+' : ''}${delta.toStringAsFixed(1)} dB');
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          SizedBox(
            width: 104,
            child: Text(
              kBandNames[i],
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
            ),
          ),
          Expanded(
            child: LayoutBuilder(
              builder: (context, box) {
                final half = box.maxWidth / 2;
                final frac = isAnchor ? 0.0 : (delta.abs() / 12.0);
                final len = half * (frac > 1.0 ? 1.0 : frac);
                return SizedBox(
                  height: 14,
                  child: Stack(
                    children: [
                      Positioned(
                        left: half - 0.5,
                        top: 0,
                        bottom: 0,
                        child: Container(width: 1, color: cs.outlineVariant),
                      ),
                      Positioned(
                        left: delta >= 0 ? half : half - len,
                        top: 3,
                        child: Container(
                          width: len,
                          height: 8,
                          decoration: BoxDecoration(
                            color: delta >= 0 ? cs.primary : cs.tertiary,
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          SizedBox(
            width: 64,
            child: Text(
              text,
              textAlign: TextAlign.end,
              style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  static String _summary(List<double> a, List<double> b) {
    var worst = -1;
    var worstAbs = 0.0;
    for (var i = 0; i < 7; i++) {
      if (i == kBandAnchor) continue;
      final d = (b[i] - a[i]).abs();
      if (d > worstAbs) {
        worstAbs = d;
        worst = i;
      }
    }
    if (worst < 0 || worstAbs < 1.5) {
      return 'El balance de frecuencias es muy parecido entre las dos.';
    }
    final d = b[worst] - a[worst];
    return 'La mayor diferencia está en ${kBandNames[worst]} '
        '(${kBandRanges[worst]}): ${d > 0 ? 'B' : 'A'} tiene '
        '${worstAbs.toStringAsFixed(1)} dB más que ${d > 0 ? 'A' : 'B'}.';
  }
}
