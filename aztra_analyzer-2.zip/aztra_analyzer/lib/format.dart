String formatClock(num seconds) {
  final total = seconds.round();
  final minutes = total ~/ 60;
  final secs = total % 60;
  return '$minutes:${secs.toString().padLeft(2, '0')}';
}

String formatBytes(int b) {
  if (b >= 1 << 30) return '${(b / (1 << 30)).toStringAsFixed(2)} GB';
  if (b >= 1 << 20) return '${(b / (1 << 20)).toStringAsFixed(1)} MB';
  if (b >= 1 << 10) return '${(b / 1024).toStringAsFixed(1)} KB';
  return '$b B';
}

String formatCount(int n) {
  if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
  if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
  return n.toString();
}

/// 16 -> "16-bit"; 0 (MP3, AAC y otros con perdida) -> "Sin dato".
String bitsLabel(int bits) => bits <= 0 ? 'Sin dato' : '$bits-bit';

/// 44100 -> "44.1 kHz", 48000 -> "48 kHz", 96000 -> "96 kHz".
String rateLabel(int hz) {
  final k = hz / 1000;
  return k == k.roundToDouble()
      ? '${k.round()} kHz'
      : '${k.toStringAsFixed(1)} kHz';
}
