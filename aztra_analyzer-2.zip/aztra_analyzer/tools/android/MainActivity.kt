package PLACEHOLDER

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {

    private var shareChannel: MethodChannel? = null
    private val pendingShared = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleShareIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
        shareChannel?.invokeMethod("sharedFiles", null)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // Canciones compartidas desde otras apps.
        val share = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "aztra/share")
        share.setMethodCallHandler { call, result ->
            when (call.method) {
                "getSharedFiles" -> {
                    val list = ArrayList(pendingShared)
                    pendingShared.clear()
                    result.success(list)
                }
                else -> result.notImplemented()
            }
        }
        shareChannel = share

        // Servicio de analisis en segundo plano.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "aztra/analysis_service")
            .setMethodCallHandler { call, result ->
                val title = call.argument<String>("title") ?: ""
                val text = call.argument<String>("text") ?: ""
                val progress = call.argument<Int>("progress") ?: -1
                val max = call.argument<Int>("max") ?: 0

                when (call.method) {
                    "start" -> {
                        val svc = Intent(this, AnalysisService::class.java)
                        svc.putExtra("title", title)
                        svc.putExtra("text", text)
                        svc.putExtra("progress", progress)
                        svc.putExtra("max", max)
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                startForegroundService(svc)
                            } else {
                                startService(svc)
                            }
                            result.success(true)
                        } catch (e: Exception) {
                            result.success(false)
                        }
                    }
                    "update" -> {
                        AnalysisService.instance?.update(title, text, progress, max)
                        result.success(true)
                    }
                    "finish" -> {
                        val service = AnalysisService.instance
                        if (service != null) {
                            service.finishWith(title, text)
                        } else {
                            stopService(Intent(this, AnalysisService::class.java))
                        }
                        result.success(true)
                    }
                    "stop" -> {
                        stopService(Intent(this, AnalysisService::class.java))
                        result.success(true)
                    }
                    "moveToBack" -> {
                        moveTaskToBack(true)
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    /** Lee las canciones que llegan por "Compartir" o "Abrir con" y las copia a la cache. */
    private fun handleShareIntent(intent: Intent?) {
        if (intent == null) return
        val uris = ArrayList<Uri>()
        when (intent.action) {
            Intent.ACTION_SEND -> {
                val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(Intent.EXTRA_STREAM)
                }
                if (uri != null) uris.add(uri)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val list: ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
                }
                if (list != null) uris.addAll(list)
            }
            Intent.ACTION_VIEW -> {
                val uri = intent.data
                if (uri != null) uris.add(uri)
            }
            else -> return
        }
        for (uri in uris) {
            val path = copyToCache(uri)
            if (path != null) pendingShared.add(path)
        }
        // Para no procesar lo mismo otra vez (por ejemplo al girar la pantalla).
        intent.action = null
    }

    private fun copyToCache(uri: Uri): String? {
        return try {
            var name = "compartida_" + System.currentTimeMillis()
            if (uri.scheme == "content") {
                contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0 && cursor.moveToFirst()) {
                        val n = cursor.getString(idx)
                        if (n != null) name = n
                    }
                }
            } else {
                val last = uri.lastPathSegment
                if (last != null) name = last.substringAfterLast('/')
            }
            val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
            val dir = File(cacheDir, "shared")
            dir.mkdirs()
            val out = File(dir, safe)
            val input = contentResolver.openInputStream(uri) ?: return null
            input.use { src ->
                out.outputStream().use { dst -> src.copyTo(dst) }
            }
            out.absolutePath
        } catch (e: Exception) {
            null
        }
    }
}
